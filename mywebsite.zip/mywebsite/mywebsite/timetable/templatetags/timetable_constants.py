# timetable/timetable_constants.py

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

# Base 1-hour slots for the full day, including explicit breaks
UNIFIED_SLOTS_FULL = [
    "10:15-11:15",
    "11:15-12:15",
    "12:15-01:15 (Break)",
    "01:15-02:15",
    "02:15-03:15",
    "03:15-03:30 (Break)",
    "03:30-04:30",
    "04:30-05:30"
]

UNIFIED_SLOTS_HALF = [
    "10:15-11:15",
    "11:15-12:15",
    "12:15-01:15 (Break)",
    "01:15-02:15",
    "02:15-03:15"
]

# Mapping for 2-hour practical blocks (start_slot_index, duration_in_1hr_slots, label for theory timetable)
# These are the *potential* slots for 2-hour blocks that can be designated as 'Practical'
PRACTICAL_DESIGNATED_BLOCKS_MAP = {
    "Morning Practical": {"start_slot_idx": 0, "duration": 2}, # 10:15-12:15
    "Afternoon Practical": {"start_slot_idx": 3, "duration": 2}, # 01:15-03:15
    "Late Afternoon Practical": {"start_slot_idx": 6, "duration": 2} # 03:30-05:30
}