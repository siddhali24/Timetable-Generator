# timetable/templatetags/timetable_extras.py

from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    """
    Allows dictionary key lookup in Django templates.
    Usage: {{ my_dict|get_item:key }} or {{ my_list|get_item:index }}
    """
    if isinstance(dictionary, dict):
        return dictionary.get(key)
    elif isinstance(dictionary, (list, tuple)):
        try:
            return dictionary[key]
        except (IndexError, TypeError):
            return None
    return None

@register.filter
def get_range(value):
    """
    Generates a range object. Useful for iterating from 0 to len(list)-1.
    Usage: {% for i in some_list|get_range %}
    """
    if isinstance(value, (list, tuple)):
        return range(len(value))
    elif isinstance(value, int):
        return range(value)
    return range(0) # Return empty range if invalid input