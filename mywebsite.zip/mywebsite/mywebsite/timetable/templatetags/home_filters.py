# timetable/templatetags/home_filters.py
import json
from django import template

register = template.Library()

@register.filter(name='json_encode_simple')
def json_encode_simple(data):
    # This filter is designed for simple Python data structures (lists, dicts)
    # that can be directly converted to JSON for JavaScript consumption.
    return json.dumps(data)

# You can keep json_encode if you use it elsewhere for QuerySets, but for
# the current use case, json_encode_simple is sufficient and clearer.
# @register.filter(name='json_encode')
# def json_encode(queryset):
#     from django.core.serializers import serialize # Import locally if not always used
#     json_data = serialize('json', queryset, use_natural_foreign_keys=True)
#     return json.dumps(json.loads(json_data))