# timetable/views.py

from django.shortcuts import render, redirect,  get_object_or_404
from .models import *
from django.contrib.auth import authenticate, login,logout
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password
from django.urls import reverse
from django.views.decorators.cache import never_cache
from .forms import *
from django.db import transaction, IntegrityError

"""
# --- GLOBAL CONSTANTS AND TIME SLOTS (from your Colab code) ---
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

UNIFIED_SLOTS_FULL = [
    "10:15-11:15",
    "11:15-12:15",
    "12:15-01:15 (Break)",
    "01:15-02:15",
    "02:15-03:15",
    "03:15-03:30 (Break)",
    "03:30-04:30",
    "04:30-05:30"
]

UNIFIED_SLOTS_HALF = [
    "10:15-11:15",
    "11:15-12:15",
    "12:15-01:15 (Break)",
    "01:15-02:15",
    "02:15-03:15"
]

PRACTICAL_DESIGNATED_BLOCKS_MAP = {
    "Morning Practical": {"start_slot_idx": 0, "duration": 2}, # 10:15-12:15
    "Afternoon Practical": {"start_slot_idx": 3, "duration": 2}, # 01:15-03:15
    "Late Afternoon Practical": {"start_slot_idx": 6, "duration": 2} # 03:30-05:30
}
"""
# timetable/views.py
# ... (keep all your existing imports and functions above this) ...

# Import for random for dummy data generation (REMOVE THIS WHEN GA IS INTEGRATED)
import random
# timetable/views.py

from django.forms import modelformset_factory
#from .utils import get_unified_slots, get_practical_designated_blocks_map # Keep these
#from .timetable_constants import DAYS, UNIFIED_SLOTS_FULL, UNIFIED_SLOTS_HALF, PRACTICAL_DESIGNATED_BLOCKS_MAP # NEW IMPORT
# Do NOT import random here; it's used within the solver, which is now a function.

# --- Backtracking Solver Logic (Abstracted from your provided Colab code) ---

# This function will encapsulate the entire logic you provided.
# It takes data similar to your `get_user_input` and returns the solved timetables.
def run_backtracking_solver(n_classes, schedule_type, practical_subjects_list, theory_data_per_class_raw):
    """
    Encapsulates the backtracking timetable generation logic.
    Converts Django model data into the format expected by the solver and runs it.

    Args:
        n_classes (int): Number of classes.
        schedule_type (str): "half day" or "full day".
        practical_subjects_list (list): List of practical subject names (e.g., ["Physics Lab", "Chemistry Lab"]).
        theory_data_per_class_raw (dict): Dictionary with class names as keys and a list of
                                          theory assignment dicts (with 'subject', 'teacher', 'freq') as values.
                                          Example: {'Class 1': [{'subject': 'Math', 'teacher': 'AB', 'freq': 4}, ...]}

    Returns:
        tuple: (solved_theory_timetable, solved_practical_timetable, batches_per_class_map)
               Returns (None, None, None) if no solution is found.
    """
    unified_slots = UNIFIED_SLOTS_HALF if schedule_type == "half day" else UNIFIED_SLOTS_FULL
    days_of_week = DAYS # Use the global DAYS constant

    # Initialize the empty timetable structures
    theory_timetable, practical_timetable, batches_per_class_map = initialize_empty_timetables(n_classes, unified_slots)

    # --- Set up Fixed Slots (Mini-Project & Mentorship) in the Theory Timetable ---
    # These are general class activities, so they appear in the class's theory timetable
    # And then the practical timetable will mirror them for all batches.

    # Mini-Project: Monday, 10:15-12:15
    mp_day = "Monday"
    mp_block_info = PRACTICAL_DESIGNATED_BLOCKS_MAP["Morning Practical"]
    mp_start_slot_idx = mp_block_info["start_slot_idx"]
    mp_duration = mp_block_info["duration"]

    if (mp_start_slot_idx + mp_duration) <= len(unified_slots) and \
       all("Break" not in unified_slots[mp_start_slot_idx + i] for i in range(mp_duration)):
        for class_name in theory_timetable.keys():
            for i in range(mp_duration):
                theory_timetable[class_name][mp_day][mp_start_slot_idx + i] = "Mini-Project"
            # Also pre-fill practical timetable for all batches with MP
            for batch in batches_per_class_map[class_name]:
                for i in range(mp_duration):
                    practical_timetable[class_name][batch][mp_day][mp_start_slot_idx + i] = "Mini-Project"
    else:
        print(f"Warning: Mini-Project 10:15-12:15 block cannot fit due to schedule type or breaks. Skipping.")

    # Mentorship: Wednesday, 01:15-03:15
    ment_day = "Wednesday"
    ment_block_info = PRACTICAL_DESIGNATED_BLOCKS_MAP["Afternoon Practical"]
    ment_start_slot_idx = ment_block_info["start_slot_idx"]
    ment_duration = ment_block_info["duration"]

    if (ment_start_slot_idx + ment_duration) <= len(unified_slots) and \
       all("Break" not in unified_slots[ment_start_slot_idx + i] for i in range(ment_duration)):
        for class_name in theory_timetable.keys():
            for i in range(ment_duration):
                theory_timetable[class_name][ment_day][ment_start_slot_idx + i] = "Mentorship"
            # Also pre-fill practical timetable for all batches with Mentorship
            for batch in batches_per_class_map[class_name]:
                for i in range(ment_duration):
                    practical_timetable[class_name][batch][ment_day][ment_start_slot_idx + i] = "Mentorship"
    else:
        print(f"Warning: Mentorship 01:15-03:15 block cannot fit due to schedule type or breaks. Skipping.")

    # Run the theory solver
    print("Attempting to generate Theory Timetables (from solver)...")
    if solve_theory_timetable(
        theory_timetable, 0, 0, 0,
        theory_data_per_class_raw, unified_slots, days_of_week, PRACTICAL_DESIGNATED_BLOCKS_MAP
    ):
        print("Theory Timetables generated successfully (from solver)!")
        print("Attempting to generate Practical Timetables (from solver)...")
        if solve_practical_timetable(
            practical_timetable, theory_timetable, batches_per_class_map, practical_subjects_list,
            0, 0, 0, 0,
            unified_slots, days_of_week, PRACTICAL_DESIGNATED_BLOCKS_MAP
        ):
            print("Practical Timetables generated successfully (from solver)!")
            return theory_timetable, practical_timetable, batches_per_class_map
        else:
            print("Could not generate Practical Timetables given the constraints and Theory Timetable.")
            return None, None, None
    else:
        print("Could not generate Theory Timetables with the given constraints.")
        return None, None, None


# --- TIMETABLE GENERATION LOGIC (FROM YOUR COLAB CODE - Paste These Below) ---
# Ensure these functions are defined in views.py (or a separate helper file)
# If placed in views.py, they should be above generate_timetables or run_backtracking_solver

import random # Keep this import here for the solver logic

def initialize_empty_timetables(n_classes, unified_slots):
    """Initializes empty structures for theory and practical timetables."""
    theory_timetable = {}
    practical_timetable = {}
    batches_per_class_map = {}

    for i in range(n_classes):
        class_name = f"Class {i + 1}"
        batch_prefix = chr(97 + i)
        batches = [f"{batch_prefix}{j + 1}" for j in range(5)] # 5 batches per class
        batches_per_class_map[class_name] = batches

        theory_timetable[class_name] = {day: [""] * len(unified_slots) for day in DAYS}

        practical_timetable[class_name] = {}
        for batch in batches:
            practical_timetable[class_name][batch] = {day: [""] * len(unified_slots) for day in DAYS}

    return theory_timetable, practical_timetable, batches_per_class_map

def solve_theory_timetable(
    theory_timetable, class_index, day_index, slot_index,
    theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
):
    """
    Backtracking function to fill the theory timetable for all classes.
    Places 'Theory Subject (Teacher)' or 'Practical' / 'Mini-Project' / 'Mentorship' markers.
    """
    # Base Case: All classes processed
    if class_index >= len(theory_data_per_class):
        # Final check: Ensure all theory subjects are covered per their frequency
        for cls_name in theory_data_per_class:
            assigned_theory_counts = {item["subject"]: 0 for item in theory_data_per_class[cls_name]}
            for d in days_of_week:
                for s_idx in range(len(unified_slots)):
                    item = theory_timetable[cls_name][d][s_idx]
                    if item and " (Theory) (" in item: # Check for theory subject
                        subject_name = item.split(" (Theory) (")[0].strip()
                        if subject_name in assigned_theory_counts:
                            assigned_theory_counts[subject_name] += 1

            for theory_info in theory_data_per_class[cls_name]:
                if assigned_theory_counts[theory_info["subject"]] != theory_info["freq"]:
                    return False # Theory frequency not met
        return True

    current_class_name = f"Class {class_index + 1}"

    # Move to next class if all days for current class are processed
    if day_index >= len(days_of_week):
        return solve_theory_timetable(
            theory_timetable, class_index + 1, 0, 0,
            theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
        )

    current_day = days_of_week[day_index]

    # Move to next day if all slots for current day are processed
    if slot_index >= len(unified_slots):
        return solve_theory_timetable(
            theory_timetable, class_index, day_index + 1, 0,
            theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
        )

    # --- Handle Breaks ---
    if "Break" in unified_slots[slot_index]:
        return solve_theory_timetable(
            theory_timetable, class_index, day_index, slot_index + 1,
            theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
        )

    # --- If the slot is already filled by the *second hour of a 2-hour block* ---
    # This prevents redundant attempts to fill a slot already implicitly taken by a 'Practical' block.
    if slot_index > 0:
        prev_slot_content = theory_timetable[current_class_name][current_day][slot_index - 1]
        if prev_slot_content in ["Practical", "Mini-Project", "Mentorship"]:
            # Check if this slot is the second hour of a 2-hour block starting at slot_index - 1
            for block_label, block_info in practical_designated_blocks.items():
                if (slot_index - 1) == block_info["start_slot_idx"] and block_info["duration"] == 2:
                    return solve_theory_timetable(
                        theory_timetable, class_index, day_index, slot_index + 1,
                        theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
                    )

    # --- Try to Assign an Item (Theory or Practical/Fixed Block) ---

    possible_items = []

    # Option 1: Try to place a Theory Subject
    assigned_theory_counts_for_class_this_week = {
        item["subject"]: 0 for item in theory_data_per_class[current_class_name]
    }
    for d in days_of_week:
        for s_idx in range(len(unified_slots)):
            item = theory_timetable[current_class_name][d][s_idx]
            if item and " (Theory) (" in item:
                subject_name = item.split(" (Theory) (")[0].strip()
                if subject_name in assigned_theory_counts_for_class_this_week:
                    assigned_theory_counts_for_class_this_week[subject_name] += 1

    needed_theory_subjects_info = []
    for theory_info in theory_data_per_class[current_class_name]:
        if assigned_theory_counts_for_class_this_week[theory_info["subject"]] < theory_info["freq"]:
            needed_theory_subjects_info.append(theory_info)

    for theory_item_info in needed_theory_subjects_info:
        subject = theory_item_info["subject"]
        teacher = theory_item_info["teacher"]

        # Check constraints before adding to possible items:
        # No subject repetition on this day for this class
        if any(theory_timetable[current_class_name][current_day][s] and theory_timetable[current_class_name][current_day][s].startswith(subject + " (Theory)") for s in range(len(unified_slots))):
            continue # Subject already assigned today

        # Teacher availability (check across all classes)
        teacher_busy = False
        for cls_name_check in theory_data_per_class: # Iterate all classes
            if theory_timetable[cls_name_check][current_day][slot_index]: # If slot occupied in another class
                if f" ({teacher})" in theory_timetable[cls_name_check][current_day][slot_index]:
                    teacher_busy = True
                    break
        if teacher_busy:
            continue

        possible_items.append({"type": "theory", "item": f"{subject} (Theory) ({teacher})", "duration": 1})

    # Option 2: Try to place a 'Practical' block (2-hour fixed slots)
    # Check if current slot is the start of a designated 2-hour practical block
    for block_label, block_info in practical_designated_blocks.items():
        if slot_index == block_info["start_slot_idx"]:
            # Check if all slots for the 2-hour block are available and not breaks
            is_block_available = True
            for i in range(block_info["duration"]):
                sub_slot_idx = slot_index + i
                if sub_slot_idx >= len(unified_slots) or \
                   "Break" in unified_slots[sub_slot_idx] or \
                   theory_timetable[current_class_name][current_day][sub_slot_idx] != "":
                    is_block_available = False
                    break
            if is_block_available:
                possible_items.append({"type": "block", "item": "Practical", "duration": block_info["duration"]}) # Label as "Practical"
            break # Only one block can start at a given slot

    random.shuffle(possible_items) # Randomize choices to explore different solutions

    for item_data in possible_items:
        item = item_data["item"]
        duration = item_data["duration"]

        # Place the item
        for i in range(duration):
            theory_timetable[current_class_name][current_day][slot_index + i] = item

        # Recurse
        if solve_theory_timetable(
            theory_timetable, class_index, day_index, slot_index + 1,
            theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
        ):
            return True
        else:
            # Backtrack: clear all slots if recursion failed
            for i in range(duration):
                theory_timetable[current_class_name][current_day][slot_index + i] = ""

    # Option 3: Leave the slot empty (off-hour) and move to the next slot
    if theory_timetable[current_class_name][current_day][slot_index] == "": # Ensure it's genuinely empty
        if solve_theory_timetable(
            theory_timetable, class_index, day_index, slot_index + 1,
            theory_data_per_class, unified_slots, days_of_week, practical_designated_blocks
        ):
            return True

    return False # No valid placement found for this slot

def solve_practical_timetable(
    practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
    class_index, batch_index, day_index, slot_index,
    unified_slots, days_of_week, practical_designated_blocks
):
    """
    Backtracking function to fill the practical timetable.
    Only fills slots marked 'Practical' in the theory timetable.
    """
    # Base Case: All classes, batches, days, and slots processed
    if class_index >= len(batches_per_class_map):
        # Final check: Ensure all practical subjects are covered exactly once for each batch
        for cls_name, batches in batches_per_class_map.items():
            for batch in batches:
                assigned_practical_subjects_for_batch_this_week = set()
                for d in days_of_week:
                    for s_idx in range(len(unified_slots)):
                        item = practical_timetable[cls_name][batch][d][s_idx]
                        if item in practical_subjects:
                            assigned_practical_subjects_for_batch_this_week.add(item)
                if len(assigned_practical_subjects_for_batch_this_week) != len(practical_subjects):
                    return False # This batch didn't cover all required practicals
        return True

    current_class_name = f"Class {class_index + 1}"
    current_batches = batches_per_class_map[current_class_name]

    # Move to next class if all batches for current class are processed
    if batch_index >= len(current_batches):
        next_class_batches = batches_per_class_map.get(f"Class {class_index + 2}", [])
        return solve_practical_timetable(
            practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
            class_index + 1, 0, 0, 0,
            unified_slots, days_of_week, practical_designated_blocks
        )

    current_batch_name = current_batches[batch_index]

    # Move to next batch if all days for current batch are processed
    if day_index >= len(days_of_week):
        return solve_practical_timetable(
            practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
            class_index, batch_index + 1, 0, 0,
            unified_slots, days_of_week, practical_designated_blocks
        )

    current_day = days_of_week[day_index]

    # Move to next day if all slots for current day are processed
    if slot_index >= len(unified_slots):
        return solve_practical_timetable(
            practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
            class_index, batch_index, day_index + 1, 0,
            unified_slots, days_of_week, practical_designated_blocks
        )

    # --- Check if current slot in Theory Timetable is a "Practical" / "Mini-Project" / "Mentorship" Block ---
    theory_slot_content = theory_timetable[current_class_name][current_day][slot_index]
    is_practical_slot_in_theory = theory_slot_content in ["Practical", "Mini-Project", "Mentorship"]

    # --- Handle Breaks or slots not designated for practicals ---
    if "Break" in unified_slots[slot_index] or not is_practical_slot_in_theory:
        # If it's a break or not a practical slot in theory timetable,
        # ensure it's empty in the practical timetable for this batch and move on.
        if practical_timetable[current_class_name][current_batch_name][current_day][slot_index] != "":
            # This should ideally not happen if logic is correct, but for robustness
            practical_timetable[current_class_name][current_batch_name][current_day][slot_index] = ""
        return solve_practical_timetable(
            practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
            class_index, batch_index, day_index, slot_index + 1,
            unified_slots, days_of_week, practical_designated_blocks
        )

    # --- If the slot is already filled by the *second hour of a 2-hour practical* ---
    if slot_index > 0:
        prev_slot_content = practical_timetable[current_class_name][current_batch_name][current_day][slot_index - 1]
        if prev_slot_content in practical_subjects or prev_slot_content in ["Mini-Project", "Mentorship"]:
            for block_label, block_info in PRACTICAL_DESIGNATED_BLOCKS_MAP.items(): # Re-using this map for structure
                if (slot_index - 1) == block_info["start_slot_idx"] and block_info["duration"] == 2:
                    # This slot is already covered by the previous 2-hour practical/fixed block
                    return solve_practical_timetable(
                        practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
                        class_index, batch_index, day_index, slot_index + 1,
                        unified_slots, days_of_week, practical_designated_blocks
                    )

    # --- Place a practical subject (or Mini-Project/Mentorship if applicable) ---

    possible_items_to_place = []

    # If the theory timetable designated this as Mini-Project or Mentorship, place that directly
    if theory_slot_content in ["Mini-Project", "Mentorship"]:
        # Ensure it's the start of the 2-hour block for MP/Mentorship
        is_mp_ment_start_slot = False
        for block_label, block_info in PRACTICAL_DESIGNATED_BLOCKS_MAP.items():
            if slot_index == block_info["start_slot_idx"]:
                is_mp_ment_start_slot = True
                break

        if is_mp_ment_start_slot:
            possible_items_to_place.append({"item": theory_slot_content, "type": "fixed", "duration": 2})

    # Otherwise, try to place a regular practical subject
    else: # It's a general "Practical" slot from theory timetable
        assigned_practical_subjects_for_batch_this_week = set()
        for d in days_of_week:
            for s_idx in range(len(unified_slots)):
                item = practical_timetable[current_class_name][current_batch_name][d][s_idx]
                if item in practical_subjects:
                    assigned_practical_subjects_for_batch_this_week.add(item)

        needed_practical_subjects = [
            sub for sub in practical_subjects if sub not in assigned_practical_subjects_for_batch_this_week
        ]

        # Check if current slot is the start of a 2-hour practical block
        is_start_of_practical_block = False
        practical_block_info = None
        for block_label, block_info in PRACTICAL_DESIGNATED_BLOCKS_MAP.items():
            if slot_index == block_info["start_slot_idx"]:
                is_start_of_practical_block = True
                practical_block_info = block_info
                break

        if is_start_of_practical_block and practical_block_info:
            for subject_to_place in needed_practical_subjects:
                # Store as (item, type, duration)
                possible_items_to_place.append({"item": subject_to_place, "type": "practical", "duration": practical_block_info["duration"]})

    random.shuffle(possible_items_to_place) # Randomize options

    for item_data in possible_items_to_place:
        item = item_data["item"]
        duration = item_data["duration"]
        item_type = item_data["type"]

        # Check if the placement is valid for all sub-slots and constraints
        all_sub_slots_valid = True

        for i in range(duration):
            sub_slot_idx = slot_index + i
            if sub_slot_idx >= len(unified_slots) or \
               "Break" in unified_slots[sub_slot_idx] or \
               practical_timetable[current_class_name][current_batch_name][current_day][sub_slot_idx] != "": # Slot must be empty for this batch
                all_sub_slots_valid = False
                break

            # Constraint: Max 3 batches can use same time slot
            # Count how many other batches (in all classes) are using this specific 1-hour slot
            batches_in_this_1hr_slot = 0
            for cls_name_check, batches_in_cls_check in batches_per_class_map.items():
                for b_check in batches_in_cls_check:
                    if b_check == current_batch_name and cls_name_check == current_class_name: continue # Don't count self
                    if practical_timetable[cls_name_check][b_check][current_day][sub_slot_idx] != "":
                        batches_in_this_1hr_slot += 1
            if batches_in_this_1hr_slot >= 3:
                all_sub_slots_valid = False
                break

            # Constraint: No same practical subject for a BATCH in a day (already checked in needed_practical_subjects)
            # This check applies only to actual practical subjects, not MP/Mentorship.
            if item_type == "practical":
                for s_idx_day in range(len(unified_slots)):
                    if practical_timetable[current_class_name][current_batch_name][current_day][s_idx_day] == item:
                        all_sub_slots_valid = False
                        break
                if not all_sub_slots_valid: break


        if all_sub_slots_valid:
            # Place the item
            for i in range(duration):
                practical_timetable[current_class_name][current_batch_name][current_day][slot_index + i] = item

            # Recurse
            if solve_practical_timetable(
                practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
                class_index, batch_index, day_index, slot_index + 1,
                unified_slots, days_of_week, practical_designated_blocks
            ):
                return True
            else:
                # Backtrack: clear all slots if recursion failed
                for i in range(duration):
                    practical_timetable[current_class_name][current_batch_name][current_day][slot_index + i] = ""

    # Option 4: Leave the slot empty (it must be empty if not a practical/fixed block)
    # This applies if no practical could be placed, but it's a designated practical block in theory.
    # If the theory says "Practical" but this batch can't use it, it remains empty for this batch.
    if practical_timetable[current_class_name][current_batch_name][current_day][slot_index] == "":
        if solve_practical_timetable(
            practical_timetable, theory_timetable, batches_per_class_map, practical_subjects,
            class_index, batch_index, day_index, slot_index + 1,
            unified_slots, days_of_week, practical_designated_blocks
        ):
            return True

    return False # No valid placement found for this slot for this batch


# --- Modified generate_timetables view ---
def generate_timetables(request):
    user_id = request.session.get('user_id')
    current_config_id = request.session.get('current_config_id')
    
    if not user_id or not current_config_id:
        messages.error(request, "No active configuration or user found to generate timetables. Please start from 'Create Time Table'.")
        return redirect('create')

    config = get_object_or_404(TimeTableInitialConfig, id=current_config_id, user__id=user_id)
    
    # Fetch all necessary data for the genetic algorithm
    practical_subjects_db = PracticalSubjectRequirement.objects.filter(configuration=config).select_related('subject')
    all_teachers_db = Teacher.objects.all() # Fetch all teachers for teacher availability checks
    timetable_classes_db = TimetableClass.objects.filter(config=config).prefetch_related('theory_assignments__subject', 'theory_assignments__teacher')

    # Prepare data for the backtracking solver
    n_classes = timetable_classes_db.count()
    schedule_type = config.schedule_type.lower() # "half day" or "full day"

    # List of practical subject names
    practical_subjects_list = [ps.subject.name for ps in practical_subjects_db]

    # Dictionary for theory data per class, in the format expected by the solver
    theory_data_per_class_raw = {}
    for tt_class in timetable_classes_db:
        class_name = tt_class.name # E.g., "Class 1"
        theory_assignments_for_class = []
        for assignment in tt_class.theory_assignments.all():
            theory_assignments_for_class.append({
                'subject': assignment.subject.name,
                'teacher': assignment.teacher.abbreviation, # Use abbreviation for teacher name in solver
                'freq': assignment.frequency,
            })
        theory_data_per_class_raw[class_name] = theory_assignments_for_class
    
    # Run the backtracking solver
    theory_timetable, practical_timetable, batches_per_class_map = run_backtracking_solver(
        n_classes, schedule_type, practical_subjects_list, theory_data_per_class_raw
    )

    if theory_timetable and practical_timetable:
        messages.success(request, "Timetables generated successfully!")
        
        # Prepare data for rendering in the template
        # The structure of `generated_timetables_output` will change to include both theory and practical
        # unified_slots and days_of_week are retrieved from the config in `run_backtracking_solver`
        # and should be consistent.
        unified_slots = UNIFIED_SLOTS_HALF if schedule_type == "half day" else UNIFIED_SLOTS_FULL
        days_of_week = DAYS # Use the global DAYS constant

        # The structure for the frontend should be easy to iterate
        # We'll combine theory and practical data per class
        # generated_timetables will be a dict:
        # {
        #   'Class 1': {
        #       'theory': {day: [slot_content, ...], ...},
        #       'practical': {batch: {day: [slot_content, ...], ...}, ...},
        #       'batches': ['a1', 'a2', ...]
        #   },
        #   'Class 2': { ... }
        # }
        final_generated_timetables = {}
        for class_name, tt_class_theory_data in theory_timetable.items():
            final_generated_timetables[class_name] = {
                'theory': tt_class_theory_data,
                'practical': practical_timetable.get(class_name, {}), # Get practical data for this class
                'batches': batches_per_class_map.get(class_name, [])
            }

        context = {
            'config': config,
            'unified_slots': unified_slots,
            'days_of_week': days_of_week,
            'generated_timetables': final_generated_timetables,
            'show_practical_table': bool(practical_subjects_list) # Only show practical table if practical subjects exist
        }
        return render(request, 'display_timetables.html', context)
    else:
        messages.error(request, "Failed to generate timetables with the given constraints. Please adjust inputs.")
        return redirect('input_theory_data') # Redirect back to theory input to adjust

# ... (keep all your existing functions below this) ...

# You might want to move these constants to a separate file like timetable_constants.py
# If you keep them here, ensure they are defined before `run_backtracking_solver`
# or any function that uses them.
# DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
# UNIFIED_SLOTS_FULL = [...]
# UNIFIED_SLOTS_HALF = [...]
# PRACTICAL_DESIGNATED_BLOCKS_MAP = {...}# ... (keep all your existing functions below this) ...
def home(request):
        return render(request,'home.html')

def register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']

        # Check if the passwords match and if the email is unique
        if password1 == password2:
            if UserRegistration.objects.filter(email=email).exists():
                messages.error(request, "Email is already taken. Please choose a different email.")
            else:
                user_registration = UserRegistration(name=name, email=email, password1=password1, password2=password2)
                user_registration.save()
                messages.success(request,"Registration successful! You can now log in.")
                return render(request, 'register.html')  # Render the same page to show message
        else:
            messages.error(request, "Passwords do not match.")

    return render(request, 'register.html')

def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        try:
            user = UserRegistration.objects.get(email=email)
            if password == user.password1:  # Direct comparison if passwords are stored in plain text
                # Set session variable or perform other login actions
                request.session['user_id'] = user.id  # Example session handling
                return redirect('dashboard')  # Redirect to 'dashboard.html'
            else:
                return render(request, 'login.html', {'error': 'Invalid password'})
        except UserRegistration.DoesNotExist:
            return render(request, 'login.html', {'error': 'User does not exist'})

    return render(request, 'login.html')

@never_cache
def custom_logout(request):
     logout(request)
     messages.success(request, "You have been logged out successfully.")
     return redirect('home.html')  # Change 'home' to your desired redirect URL


@never_cache
def sign_out(request):
    logout(request)  # Log the user out and clear the session
    return redirect('home')  # Redirect to the home page

def forgot(request):
    return render(request,'forgot.html')

def dashboard(request):
    user_id = request.session.get('user_id')  # Get the logged-in user's ID from the session
    if user_id:
        user = UserRegistration.objects.get(id=user_id)  # Fetch user details from the database
        return render(request, 'dashboard.html', {'user': user})
    else:
        return redirect('login')  # Redirect to login if not logged in


def profile_view(request):
    user_id = request.session.get('user_id')  # Get the user ID from the session
    if not user_id:
        return redirect('login')  # Redirect to login if the user is not logged in

    user_profile = get_object_or_404(UserRegistration, id=user_id)

    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # Redirect after successful update
    else:
        form = UserProfileForm(instance=user_profile)

    return render(request, 'profile_view.html', {'form': form, 'user_profile': user_profile})

# --- GLOBAL CONSTANTS AND TIME SLOTS (from your Colab code) ---
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

UNIFIED_SLOTS_FULL = [
    "10:15-11:15",
    "11:15-12:15",
    "12:15-01:15 (Break)",
    "01:15-02:15",
    "02:15-03:15",
    "03:15-03:30 (Break)",
    "03:30-04:30",
    "04:30-05:30"
]

UNIFIED_SLOTS_HALF = [
    "10:15-11:15",
    "11:15-12:15",
    "12:15-01:15 (Break)",
    "01:15-02:15",
    "02:15-03:15"
]

PRACTICAL_DESIGNATED_BLOCKS_MAP = {
    "Morning Practical": {"start_slot_idx": 0, "duration": 2}, # 10:15-12:15
    "Afternoon Practical": {"start_slot_idx": 3, "duration": 2}, # 01:15-03:15
    "Late Afternoon Practical": {"start_slot_idx": 6, "duration": 2} # 03:30-05:30
}

def create(request):
     if not request.session.get('user_id'):
        messages.error(request, "Please log in to create a timetable configuration.")
        return redirect('login') # Redirect to your login page

     return render(request, 'create.html')
    

def configure_initial_parameters(request):
    """
    Handles the submission from the create.html form.
    Captures the number of timetables and schedule type,
    stores them in the session, and redirects to the next step
    for practical subjects input.
    """
    if request.method == 'POST':
        # Retrieve data from the POST request
        user_id = request.session.get('user_id')
        if not user_id:
            messages.error(request, "You must be logged in to create a configuration.")
            return redirect('login')
        
        # Retrieve the logged-in user object
        current_user = get_object_or_404(UserRegistration, id=user_id)

        config_name = request.POST.get('config_name')
        time_table_count = request.POST.get('time_table_count')
        schedule_type = request.POST.get('schedule_type')
        
        # --- Basic Input Validation ---
        if not config_name or not time_table_count or not schedule_type:
            messages.error(request, "All fields (Configuration Name, Number of Timetables, Schedule) are required.")
            return redirect('create')

        try:
            time_table_count = int(time_table_count)
            if time_table_count not in [1, 2]:
                messages.error(request, "Number of timetables must be 1 or 2.")
                return redirect('create')
        except ValueError:
            messages.error(request, "Invalid number of timetables specified.")
            return redirect('create')

        if schedule_type not in ['half_day', 'full_day']:
            messages.error(request, "Invalid schedule type selected.")
            return redirect('create')
        
        # --- Check for existing configuration name in TimeTableInitialConfig ---
        if TimeTableInitialConfig.objects.filter(name=config_name).exists():
            messages.error(request, f"A configuration named '{config_name}' already exists. Please choose a different name.")
            return redirect('create')

        # --- Save to TimeTableInitialConfig Model in Database ---
        try:
            new_config = TimeTableInitialConfig.objects.create(
                user=current_user,
                name=config_name,
                num_timetables=time_table_count, # Use num_timetables as per the new model
                schedule_type=schedule_type
            )

            # --- Store Configuration ID in Session ---
            # This ID will be used in subsequent steps to link all related data
            request.session['current_config_id'] = new_config.id
            request.session['current_config_name'] = new_config.name # Also store name for convenience

            # Store unified slots and other global constants for the generation process
            if schedule_type == 'half_day':
                request.session['unified_slots'] = UNIFIED_SLOTS_HALF
            else:
                request.session['unified_slots'] = UNIFIED_SLOTS_FULL
            
            request.session['practical_designated_blocks_map'] = PRACTICAL_DESIGNATED_BLOCKS_MAP
            request.session['days_of_week'] = DAYS

            messages.success(request, f"Configuration '{config_name}' saved. Ready for the next steps.")
            
            # Redirect to the next page. This view (input_practical_subjects) is yet to be fully defined.
            # For now, it will simply render a blank page with context.
            return redirect('input_practical_subjects') # This URL needs to be in your urls.py

        except Exception as e:
            messages.error(request, f"An error occurred while saving the configuration: {e}")
            print(f"Error saving initial configuration to database: {e}") # Log the full error
            return redirect('create')

    else:
        # If it's a GET request, redirect back to create (or render the form directly)
        return redirect('create')

# --- Placeholder for the next view (input_practical_subjects) ---
# You've already included this, just ensuring it's here for context for the next steps.
def input_practical_subjects(request):
    """
    Renders the form to input practical subjects.
    It retrieves the current configuration and pre-populates existing practicals.
    """
    user_id = request.session.get('user_id')
    current_config_id = request.session.get('current_config_id')

    if not user_id:
        messages.error(request, "Please log in to manage your configurations.")
        return redirect('login')
    if not current_config_id:
        messages.error(request, "No configuration selected. Please start from 'Create Time Table'.")
        return redirect('create')

    current_user = get_object_or_404(UserRegistration, id=user_id)
    config = get_object_or_404(TimeTableInitialConfig, id=current_config_id, user=current_user)

    # Fetch existing practical subject requirements for this configuration
    existing_practical_requirements = PracticalSubjectRequirement.objects.filter(configuration=config).order_by('subject__name')
    existing_practical_count = existing_practical_requirements.count()

    context = {
        'config': config,
        'existing_practical_requirements': existing_practical_requirements,
        'existing_practical_count': existing_practical_count, # To pre-fill the number input
    }
    return render(request, 'input_practical_subjects.html', context)


# --- Other placeholder views (process_practical_subjects, input_theory_data, etc.) ---
# These will be fleshed out as you restructure your pages,
# and will use the 'current_config_id' from the session to link data.

def process_practical_subjects(request):
    """
    Handles the submission of practical subjects.
    It will now save them to the `PracticalSubjectRequirement` model,
    linked to the current `TimeTableInitialConfig`.
    It creates new Subject entries if the name doesn't exist.
    """
    user_id = request.session.get('user_id')
    current_config_id = request.session.get('current_config_id')

    if not user_id:
        messages.error(request, "You must be logged in to process practical subjects.")
        return redirect('login')
    if not current_config_id:
        messages.error(request, "Configuration not found. Please start over.")
        return redirect('create')

    current_user = get_object_or_404(UserRegistration, id=user_id)
    config = get_object_or_404(TimeTableInitialConfig, id=current_config_id, user=current_user)

    if request.method == 'POST':
        practical_subject_names = request.POST.getlist('practical_subjects') # This gets all names from dynamic inputs
        num_practical_subjects_input = request.POST.get('num_practical_subjects')

        # Basic validation
        if not num_practical_subjects_input:
            messages.error(request, "Number of practical subjects is required.")
            return redirect('input_practical_subjects')
        
        try:
            num_practical_subjects_int = int(num_practical_subjects_input)
            if num_practical_subjects_int < 0:
                messages.error(request, "Number of practical subjects cannot be negative.")
                return redirect('input_practical_subjects')
        except ValueError:
            messages.error(request, "Invalid number of practical subjects.")
            return redirect('input_practical_subjects')

        # If the user entered 0, clear all practical requirements for this config
        if num_practical_subjects_int == 0:
            PracticalSubjectRequirement.objects.filter(configuration=config).delete()
            messages.success(request, "No practical subjects configured.")
            return redirect('register_teacher') # Move to next step

        # Validate that the number of submitted names matches the expected count
        if len(practical_subject_names) != num_practical_subjects_int:
             messages.error(request, "Mismatch between number of practical subjects entered and names provided. Please generate fields and fill them correctly.")
             return redirect('input_practical_subjects')


        try:
            # Clear existing practical subjects for this configuration to prevent duplicates on resubmission
            PracticalSubjectRequirement.objects.filter(configuration=config).delete()

            for subject_name in practical_subject_names:
                subject_name = subject_name.strip()
                if not subject_name:
                    messages.warning(request, "Empty practical subject name found and skipped.")
                    continue

                # Get or create the Subject object.
                # If a Subject with this name and 'practical' type already exists, use it.
                # Otherwise, create a new one.
                subject, created = Subject.objects.get_or_create(
                    name=subject_name,
                    defaults={'subject_type': 'practical'} # Set type to practical if creating
                )
                # If subject already exists but its type is not practical, you might want to handle this
                if not created and subject.subject_type != 'practical':
                    messages.warning(request, f"Subject '{subject_name}' already exists but is not a practical type. Skipping.")
                    continue

                # Create the PracticalSubjectRequirement linking the config and the subject
                PracticalSubjectRequirement.objects.create(
                    configuration=config,
                    subject=subject
                )
            
            messages.success(request, "Practical subjects saved successfully!")
            return redirect('register_teacher') # Redirect to the next step

        except Exception as e:
            messages.error(request, f"Error saving practical subjects: {e}")
            print(f"Error saving practical subjects: {e}")
            return redirect('input_practical_subjects')
    else:
        return redirect('input_practical_subjects') # Redirect GET requests back to the form

def input_theory_data(request):
    user_id = request.session.get('user_id')
    current_config_id = request.session.get('current_config_id')

    if not user_id:
        messages.error(request, "Please log in to manage your configurations.")
        return redirect('login')
    if not current_config_id:
        messages.error(request, "No configuration selected. Please start from 'Create Time Table'.")
        return redirect('create')

    current_user = get_object_or_404(UserRegistration, id=user_id)
    config = get_object_or_404(TimeTableInitialConfig, id=current_config_id, user=current_user)

    teachers = Teacher.objects.all().order_by('name')
    
    # Prepare teachers data as a list of dictionaries for JavaScript
    teachers_list_for_js = []
    for teacher in teachers:
        teachers_list_for_js.append({
            'pk': teacher.pk,
            'fields': {
                'name': teacher.name,
                'abbreviation': teacher.abbreviation
            }
        })

    timetable_classes = []
    for i in range(1, config.num_timetables + 1):
        class_name = f"Class {i}"
        timetable_class, created = TimetableClass.objects.get_or_create(
            config=config,
            class_number=i,
            defaults={'name': class_name}
        )
        timetable_classes.append(timetable_class)
    
    classes_with_assignments = []
    for tc in timetable_classes:
        assignments = TheoryAssignment.objects.filter(timetable_class=tc).select_related('subject', 'teacher').order_by('subject__name')
        
        assignments_data = []
        for assignment in assignments:
            assignments_data.append({
                'id': assignment.id, # Keep ID for potential future use (e.g., update/delete individual assignments)
                'subject__name': assignment.subject.name,
                'frequency': assignment.frequency,
                'teacher__id': assignment.teacher.id,
                'teacher__name': assignment.teacher.name, # For display/debugging
                'teacher__abbreviation': assignment.teacher.abbreviation, # For display/debugging
            })

        classes_with_assignments.append({
            'class': tc,
            'assignments': assignments_data, # Use the prepared list of dicts
            'num_assignments': len(assignments_data)
        })

    context = {
        'config': config,
        'teachers': teachers_list_for_js, # Pass the prepared list for JS
        'classes_with_assignments': classes_with_assignments,
        'num_timetables': config.num_timetables,
    }
    return render(request, 'input_theory_data.html', context)


def process_theory_data(request):
    user_id = request.session.get('user_id')
    current_config_id = request.session.get('current_config_id')

    if not user_id:
        messages.error(request, "You must be logged in to process theory data.")
        return redirect('login')
    if not current_config_id:
        messages.error(request, "Configuration not found. Please start over.")
        return redirect('create')

    current_user = get_object_or_404(UserRegistration, id=user_id)
    config = get_object_or_404(TimeTableInitialConfig, id=current_config_id, user=current_user)

    if request.method == 'POST':
        try:
            with transaction.atomic():
                # Loop through each class based on the configured number of timetables
                for i in range(1, config.num_timetables + 1):
                    class_name = f"Class {i}"
                    timetable_class = get_object_or_404(TimetableClass, config=config, class_number=i)

                    # Get the number of subjects expected for this class from the form
                    num_subjects_str = request.POST.get(f'num_theory_subjects_class_{i}', '0')
                    try:
                        num_subjects = int(num_subjects_str)
                    except ValueError:
                        messages.error(request, f"Invalid number of subjects specified for {class_name}.")
                        # Re-raise to trigger rollback
                        raise ValueError(f"Invalid number of subjects for {class_name}")
                    
                    if num_subjects < 0:
                        messages.error(request, f"Number of subjects cannot be negative for {class_name}.")
                        raise ValueError(f"Number of subjects cannot be negative for {class_name}")

                    # --- IMPORTANT: Clear existing assignments for this class BEFORE adding new ones ---
                    TheoryAssignment.objects.filter(timetable_class=timetable_class).delete()

                    # Process each submitted subject for the current class
                    for j in range(num_subjects):
                        subject_name = request.POST.get(f'subject_name_class_{i}_{j}')
                        frequency_str = request.POST.get(f'frequency_class_{i}_{j}')
                        teacher_id_str = request.POST.get(f'teacher_class_{i}_{j}')

                        # Basic validation for individual fields
                        if not subject_name or not frequency_str or not teacher_id_str:
                            messages.error(request, f"Missing data for Subject {j+1} in {class_name}. All fields (Subject Name, Frequency, Teacher) are required.")
                            raise ValueError(f"Missing data for Subject {j+1} in {class_name}")

                        try:
                            frequency = int(frequency_str)
                            if frequency <= 0:
                                messages.error(request, f"Frequency must be a positive number for Subject '{subject_name}' in {class_name}.")
                                raise ValueError(f"Frequency must be positive for Subject '{subject_name}' in {class_name}")
                        except ValueError:
                            messages.error(request, f"Invalid frequency format for Subject '{subject_name}' in {class_name}.")
                            raise ValueError(f"Invalid frequency format for Subject '{subject_name}' in {class_name}")

                        try:
                            teacher_id = int(teacher_id_str)
                            teacher = get_object_or_404(Teacher, id=teacher_id)
                        except (ValueError, Teacher.DoesNotExist):
                            messages.error(request, f"Invalid teacher selected for Subject '{subject_name}' in {class_name}. Please ensure the teacher exists.")
                            raise ValueError(f"Invalid teacher selected for Subject '{subject_name}' in {class_name}")

                        # Get or create the Subject object
                        subject, created = Subject.objects.get_or_create(
                            name=subject_name.strip(),
                            subject_type='theory',
                            defaults={'subject_type': 'theory'}
                        )
                        # If a subject with the same name but different type exists, this will create a new 'theory' subject.
                        # If you want to prevent names like "ML" (practical) from being reused as "ML" (theory),
                        # you'd need more complex logic, but `unique_together=('name', 'subject_type')` handles the distinctness.
                        
                        # Create the TheoryAssignment
                        TheoryAssignment.objects.create(
                            timetable_class=timetable_class,
                            subject=subject,
                            teacher=teacher,
                            frequency=frequency
                        )
            
            messages.success(request, "Theory subjects saved successfully!")
            return redirect('generate_timetables')

        except ValueError as ve:
            # Messages are already set by the specific error conditions in the try block
            print(f"Validation error in process_theory_data: {ve}")
            return redirect('input_theory_data') 
        except Exception as e:
            messages.error(request, f"An unexpected error occurred while saving theory subjects: {e}")
            print(f"Unhandled error saving theory subjects: {e}")
            return redirect('input_theory_data')
    else:
        return redirect('input_theory_data')

def register_teacher(request):
    """
    Allows users to register new teachers by providing their name and abbreviation.
    Uses TeacherForm for robust validation and saving.
    Also displays a list of existing teachers.
    """
    user_id = request.session.get('user_id')

    if not user_id:
        messages.error(request, "Please log in to register teachers.")
        return redirect('login')  # Redirect to login if not authenticated

    if request.method == 'POST':
        form = TeacherForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                messages.success(
                    request,
                    f"Teacher '{form.cleaned_data['name']}' with abbreviation '{form.cleaned_data['abbreviation']}' registered successfully!"
                )
                return redirect('register_teacher')  # Refresh page after successful registration
            except IntegrityError:
                messages.error(
                    request,
                    f"Teacher with abbreviation '{form.cleaned_data['abbreviation']}' already exists. Please choose a unique abbreviation."
                )
            except Exception as e:
                messages.error(request, f"An error occurred: {e}")
                print(f"Error: {e}")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.capitalize()}: {error}")
    else:
        form = TeacherForm()

    teachers = Teacher.objects.all().order_by('name')
    context = {
        'form': form,
        'teachers': teachers,
    }
    return render(request, 'register_teacher.html', context)