# timetable/models.py

from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager, PermissionsMixin

# If you use Django's built-in User, you might not need UserRegistration.
# Assuming UserRegistration is your custom user model as per your code.
class UserRegistration(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password1 = models.CharField(max_length=255) # Storing plain text password for now
    password2 = models.CharField(max_length=255) # Storing plain text password for now

    def __str__(self):
        return self.email

# New models for Timetable configuration and data
class TimeTableInitialConfig(models.Model):
    user = models.ForeignKey(UserRegistration, on_delete=models.CASCADE, related_name='timetable_configs')
    name = models.CharField(max_length=100, help_text="A unique name for this timetable configuration (e.g., 'Sem 5 Full Day A')")
    num_timetables = models.PositiveIntegerField(choices=[(1, '1'), (2, '2')], default=1)
    schedule_type_choices = [
        ('half_day', 'Half Day (10:15 AM - 3:15 PM)'),
        ('full_day', 'Full Day (10:15 AM - 5:30 PM)'),
    ]
    schedule_type = models.CharField(max_length=10, choices=schedule_type_choices, default='half_day')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'name') # Ensure a user can't have two configs with the same name

    def __str__(self):
        return f"{self.user.email} - {self.name} ({self.get_schedule_type_display()})"

class Subject(models.Model):
    # Subject can be 'theory' or 'practical'
    SUBJECT_TYPE_CHOICES = [
        ('theory', 'Theory'),
        ('practical', 'Practical'),
    ]
    name = models.CharField(max_length=100)
    subject_type = models.CharField(max_length=10, choices=SUBJECT_TYPE_CHOICES)

    class Meta:
        # Ensures that "ML" as a theory subject is distinct from "ML" as a practical subject
        unique_together = ('name', 'subject_type')
        ordering = ['name', 'subject_type'] # Order by name then type

    def __str__(self):
        return f"{self.name} ({self.get_subject_type_display()})"

class PracticalSubjectRequirement(models.Model):
    configuration = models.ForeignKey(TimeTableInitialConfig, on_delete=models.CASCADE, related_name='practical_requirements')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, limit_choices_to={'subject_type': 'practical'})

    class Meta:
        unique_together = ('configuration', 'subject') # Each practical subject unique per config
        verbose_name = "Practical Subject Requirement"
        verbose_name_plural = "Practical Subject Requirements"

    def __str__(self):
        return f"{self.subject.name} (Practical) for {self.configuration.name}"

class Teacher(models.Model):
    name = models.CharField(max_length=100)
    abbreviation = models.CharField(max_length=10, unique=True, help_text="Short code for the teacher (e.g., 'RJ', 'SK')")

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.abbreviation})"

class TimetableClass(models.Model):
    # Represents a specific class (e.g., Class 1, Class 2) within a configuration
    config = models.ForeignKey(TimeTableInitialConfig, on_delete=models.CASCADE, related_name='classes')
    class_number = models.PositiveIntegerField(help_text="e.g., 1 for Class 1, 2 for Class 2")
    name = models.CharField(max_length=50, blank=True, null=True, help_text="Display name for the class (e.g., 'TY B.Tech CSE A')")

    class Meta:
        unique_together = ('config', 'class_number') # Ensures Class 1 and Class 2 are unique per config
        ordering = ['class_number']
        verbose_name_plural = "Timetable Classes"

    def __str__(self):
        return f"{self.name or f'Class {self.class_number}'} ({self.config.name})"

class TheoryAssignment(models.Model):
    # Assigns a theory subject to a teacher for a specific class, with a frequency
    timetable_class = models.ForeignKey(TimetableClass, on_delete=models.CASCADE, related_name='theory_assignments')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, limit_choices_to={'subject_type': 'theory'})
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, related_name='theory_teachings')
    frequency = models.PositiveIntegerField(help_text="Number of periods per week for this subject in this class")

    class Meta:
        unique_together = ('timetable_class', 'subject') # A subject can only be assigned once per class
        verbose_name = "Theory Subject Assignment"
        verbose_name_plural = "Theory Subject Assignments"
        ordering = ['subject__name']

    def __str__(self):
        return f"{self.subject.name} ({self.frequency} hrs) by {self.teacher.abbreviation} for {self.timetable_class.name}"