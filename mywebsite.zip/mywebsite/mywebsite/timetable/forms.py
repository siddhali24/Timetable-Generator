from django import forms
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth.forms import UserCreationForm

class RegistrationForm(UserCreationForm):
    name = forms.CharField(max_length=30, required=True, label='Full Name')
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ('name', 'email', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.first_name = self.cleaned_data['name']  # Save name to the first name field
        user.email = self.cleaned_data['email']
        user.password = self.cleaned_data['password1'] 
        if commit:
            user.save()
        return user


class UserProfileForm(forms.ModelForm):
    password1 = forms.CharField(widget=forms.PasswordInput, label="Password")

    class Meta:
        model = UserRegistration
        fields = ['name', 'email', 'password1']

class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = ['name', 'abbreviation']
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'e.g., Dr. Smith'}),
            'abbreviation': forms.TextInput(attrs={'placeholder': 'e.g., DMS', 'maxlength': '10'}),
        }
        labels = {
            'name': 'Teacher Name',
            'abbreviation': 'Abbreviation (Unique, max 10 chars)',
        }