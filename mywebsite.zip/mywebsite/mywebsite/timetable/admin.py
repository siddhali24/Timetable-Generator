from django.contrib import admin
from .models import *

@admin.register(UserRegistration)
class UserRegistrationAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'password1', 'password2')  # Adjust as needed
    search_fields = ('name', 'email')  # Enable search by name or email


@admin.register(TimeTableInitialConfig)
class TimeTableInitialConfigAdmin(admin.ModelAdmin):
    list_display = ('name', 'num_timetables', 'schedule_type', 'created_at')
    list_filter = ('schedule_type',)
    search_fields = ('name',)

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'subject_type')
    list_filter = ('subject_type',)
    search_fields = ('name',)

@admin.register(PracticalSubjectRequirement)
class PracticalSubjectRequirementAdmin(admin.ModelAdmin):
    list_display = ('configuration', 'subject')
    list_filter = ('configuration__name', 'subject__name')
    search_fields = ('configuration__name', 'subject__name')    


@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ('name', 'abbreviation')
    search_fields = ('name', 'abbreviation')


@admin.register(TheoryAssignment)
class TheoryAssignmentAdmin(admin.ModelAdmin):
    list_display = ('timetable_class', 'subject', 'teacher', 'frequency')
    list_filter = ('timetable_class__config__name', 'timetable_class__name', 'subject__name', 'teacher__name')
    search_fields = ('subject__name', 'teacher__name')    