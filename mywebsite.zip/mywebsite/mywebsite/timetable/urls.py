
from django.urls import path
from .views import *


urlpatterns = [
    path('register/', register, name='register'),
    path('login/', login, name='login'),
    path('forgot/', forgot, name='forgot'),
    path('logout/', sign_out, name='logout'),
    path('logout1/', custom_logout, name='logout1'),
    path('',home,name='home'),
    path('dashboard/',dashboard, name='dashboard'),
    path('profile/',profile_view, name='profile'),
    path('create/',create, name='create'),
    path('input-theory-data/', input_theory_data, name='input_theory_data'),
    path('process-theory-data/',process_theory_data, name='process_theory_data'),

    path('configure-initial-parameters/', configure_initial_parameters, name='configure_initial_parameters'),
   # New paths for practical subjects
    path('input-practical-subjects/', input_practical_subjects, name='input_practical_subjects'),
    path('process-practical-subjects/', process_practical_subjects, name='process_practical_subjects'),
    path('register-teacher/', register_teacher, name='register_teacher'),
    path('generate-timetables/', generate_timetables, name='generate_timetables'),
    #path('display-timetables/', display_timetables, name='display_timetables'), # New URL for displaying

]


